drop database if exists lportal;
create database lportal character set utf8;
use lportal;





