drop database lportal;
create database lportal pagesize 8192;
connect to lportal;




