drop database lportal;
create database lportal;

go

use lportal;





